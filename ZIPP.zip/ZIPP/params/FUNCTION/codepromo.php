<?php

if($_POST['CP'] == "promo-2020")
{
    $prix_TTC = $prix_TTC * 20/100;
}

?>