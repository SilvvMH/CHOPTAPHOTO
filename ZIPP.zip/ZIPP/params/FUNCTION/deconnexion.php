<?php
include('visiteurs/home.php');
session_destroy();
?>
<script>
    // redirection
    window.location.href = "index.php";
</script>