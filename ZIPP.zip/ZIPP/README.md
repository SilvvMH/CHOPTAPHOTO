#ChopTaPhoto2.0
 

Informations sur le PPE2 de Silvère et Benoit :


Connexion & inscription :

Dans un premier temps si vous voulez créer un compte administrateur sur notre site, ce qui vous permettra d’ajouter des stocks à nos produits et de modifier les informations des produits il faut : 

-	Créer un compte a partir de notre page : choptaphoto/index.php?page=inscription 
-	Mettre votre vrai nom/prénom/âge/ville/email (il est obligatoire de tout remplir sinon votre compte ne sera pas créé)
-	Mettre comme mot de passe : admin-admin 
-	Puis enregistrer, vous aller être rediriger vers la page connexion automatiquement.
-	Rentrer votre email et le mot de passe : admin-admin
-	Quand vous êtes connecté, cliquer sur l’onglet « compte » et voir votre « rôle administrateur » 

Dans un deuxième temps si vous voulez créer un compte client sur notre site, ce qui vous permettra d’ajouter des produits a votre panier et commander il faut :

-	Créer un compte à partir de notre page : choptaphoto/index.php?page=inscription 
-	Remplir les informations demandées (il est obligatoire de tout remplir sinon votre compte ne sera pas créé)
-	Puis enregistrer, vous aller être rediriger vers la page connexion automatiquement.
-	Rentrer vos informations (email et mot de passe)
-	Quand vous êtes connecté, cliquer sur l’onglet « compte » et voir votre « rôle client » 

Modifier son adresse mail, son mot de passe ou ses informations c’est très simple, il faut : 
-	Connectez-vous à votre compte et aller dans l’onglet « compte » 
-	Aller en bas de la page et cliquer sur « modifier mon mot de passe »
-	Aller en bas de la page et cliquer sur « modifier mon email »





Le panier :

Dans un premier temps si vous n’êtes pas client à choptaphoto vous n’avez pas accès au panier, vous pouvez regarder les produits mais si vous voulez passer à l’étape de l’ajout ou du payement de la commande il vous faudra vous inscrire ou vous connecter à votre espace client. 
*Pour mettre au panier un produit il suffit de cliquer sur le bouton réserver et de choisir la quantité que vous voulez !

Si vous êtes connecté, mais que vous n’avez pas encore mis des produits dans votre panier Choptaphoto vous indiquera que pour voir des produits vous devez d’abord « réserver » depuis le catalogue.

Vous êtes un visiteur sans compte ? 
-	Vous pouvez regarder les pages produits dans le catalogue mais si vous voulez passer à l’étape de mettre au panier il vous faudra vous inscrire ou vous connecter. (Inscrivez-vous simplement dans l’onglet : choptaphoto/index.php?page=inscription) .
Vous êtes un client/administrateur avec un compte ? 
- Connectez-vous à votre espace client
- Recherche les produits à acheter, et les mettre dans le panier (* voir index plus haut) 
- Si vous voulez plusieurs produits, n’ayez pas peur vous pouvez retourner sur le catalogue des produits sans que votre panier disparaisse. 
- Si vous voulez supprimer des produits à partir du panier, vous avez juste à cliquer sur la petite poubelle a droite de votre produit.
- Pour valider votre commande et procéder au payement, vous avez juste à cliquer sur le bouton « commander » en bas a droite de votre panier. 

Si votre quantité de produit dépasse notre stock vous recevrez un message vous informant que votre demande ne peut pas aboutir car le nombre demandé de produit et supérieur a notre stock. 





